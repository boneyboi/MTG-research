package forge.game.research;

import forge.card.mana.ManaCostShard;
import forge.game.card.Card;

public class evaluateValue{
    public final Double evalVal(Card card){

        Double shardmana = 0.0;
        for(ManaCostShard m : ManaCostShard.values()){
            if(m==ManaCostShard.GENERIC){continue;}
            if(card.getManaCost().getShardCount(m)!=0){
                shardmana += (card.getManaCost().getShardCount(m)*0.75);
                shardmana += ((card.getManaCost().getShardCount(m)/card.getManaCost().getShardCount(m))*0.25);
            }
        }
        return 0.5 + (card.getCurrentPower() - card.getBasePower())
                + (card.getCurrentToughness() - card.getBaseToughness())
                + (card.getCMC()*2) + shardmana;
    }
}